// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_CEL_CPP_COMMON_UNKNOWN_H_
#define THIRD_PARTY_CEL_CPP_COMMON_UNKNOWN_H_

#include "base/internal/unknown_set.h"

namespace cel {

// `Unknown` is a collection of unknown attributes and function results.
using Unknown = base_internal::UnknownSet;

}  // namespace cel

#endif  // THIRD_PARTY_CEL_CPP_COMMON_UNKNOWN_H_
