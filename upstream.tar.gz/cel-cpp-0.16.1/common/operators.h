// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef THIRD_PARTY_CEL_CPP_COMMON_OPERATORS_H_
#define THIRD_PARTY_CEL_CPP_COMMON_OPERATORS_H_

#include <map>
#include <string>

#include "cel/expr/syntax.pb.h"
#include "absl/strings/string_view.h"
#include "absl/types/optional.h"

namespace google::api::expr::common {

// Operator function names.
struct CelOperator {
  static const char* CONDITIONAL;
  static const char* LOGICAL_AND;
  static const char* LOGICAL_OR;
  static const char* LOGICAL_NOT;
  static const char* IN_DEPRECATED;
  static const char* EQUALS;
  static const char* NOT_EQUALS;
  static const char* LESS;
  static const char* LESS_EQUALS;
  static const char* GREATER;
  static const char* GREATER_EQUALS;
  static const char* ADD;
  static const char* SUBTRACT;
  static const char* MULTIPLY;
  static const char* DIVIDE;
  static const char* MODULO;
  static const char* NEGATE;
  static const char* INDEX;
  // Macros
  static const char* HAS;
  static const char* ALL;
  static const char* EXISTS;
  static const char* EXISTS_ONE;
  static const char* MAP;
  static const char* FILTER;

  // Named operators, must not have be valid identifiers.
  static const char* NOT_STRICTLY_FALSE;
#pragma push_macro("IN")
#undef IN
  static const char* IN;
#pragma pop_macro("IN")

  static const absl::string_view OPT_INDEX;
  static const absl::string_view OPT_SELECT;
};

// These give access to all or some specific precedence value.
// Higher value means higher precedence, 0 means no precedence, i.e.,
// custom function and not builtin operator.
int LookupPrecedence(absl::string_view op);

absl::optional<std::string> LookupUnaryOperator(absl::string_view op);
absl::optional<std::string> LookupBinaryOperator(absl::string_view op);
absl::optional<std::string> LookupOperator(absl::string_view op);
absl::optional<std::string> ReverseLookupOperator(absl::string_view op);

// returns true if op has a lower precedence than the one expressed in expr
bool IsOperatorLowerPrecedence(absl::string_view op,
                               const cel::expr::Expr& expr);
// returns true if op has the same precedence as the one expressed in expr
bool IsOperatorSamePrecedence(absl::string_view op,
                              const cel::expr::Expr& expr);
// return true if operator is left recursive, i.e., neither && nor ||.
bool IsOperatorLeftRecursive(absl::string_view op);

}  // namespace google::api::expr::common

#endif  // THIRD_PARTY_CEL_CPP_COMMON_OPERATORS_H_
